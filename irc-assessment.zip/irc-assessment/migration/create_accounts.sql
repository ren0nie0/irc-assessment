CREATE TABLE IF NOT EXISTS accounts (
  account_id varchar(255) PRIMARY KEY,
  account_type varchar(255),
  billing_country varchar(255)
)